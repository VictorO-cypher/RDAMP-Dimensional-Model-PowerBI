INSERT INTO fact_sales (
    order_id, customer_id, product_id, region_id, order_date, order_mode_id, segment_id,
    quantity, cost_price, sales_amount, profit, discount_amount
) VALUES (
    'O001', 'C001', 'P001', 'R001', '2025-07-01', 'OM001', 'S001',
    2, 500.00, 1200.00, 200.00, 100.00
);