-- Example inserts (replace with your cleaned data)
INSERT INTO dim_customer VALUES ('C001', 'London', 'EC1A', 'England');
INSERT INTO dim_product VALUES ('P001', 'Electric Bike', 'CAT001', 'Bikes');
INSERT INTO dim_category VALUES ('CAT001', 'Electronics');
INSERT INTO dim_location VALUES ('R001', 'South');
INSERT INTO dim_date VALUES ('2025-07-01', 2025, 'July', 'Q3');
INSERT INTO dim_segment VALUES ('S001', 'Consumer');
INSERT INTO dim_order_mode VALUES ('OM001', 'Online');